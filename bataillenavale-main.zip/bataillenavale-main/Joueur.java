package batailleNavale;

import java.util.Scanner;

public abstract class Joueur {
	public final static int TOUCHE = 1;
	public final static int COULE = 2;
	public final static int A_L_EAU = 3;
	public final static int GAMEOVER = 4;
	private Joueur adversaire;
	private int tailleGrille;
	private String nom;
	
	public Joueur(int tailleGrille, String nom) {
		this.tailleGrille = tailleGrille;
		this.nom = nom;
	}
	
	 public Joueur(int tailleGrille) {
		 this.tailleGrille = tailleGrille;
	 }
	 
	 public int getTailleGrille() {
		 return tailleGrille;
	 }
	 
	 public String getNom() {
		 return nom;
	 }

	 public void jouerAvec(Joueur j) {
		 this.adversaire = j;
		 j.adversaire = this;
		 deroulementJeu(this, j);
		
	 }
	 
	 private static void deroulementJeu( Joueur attaquant,Joueur defenseur) {
		 int res = 0;
		 while (res != GAMEOVER) {
		 Coordonnee c = attaquant.choixAttaque();
		 res = defenseur.defendre(c);
		 attaquant.retourAttaque(c, res);
		 defenseur.retourDefense(c, res);
		 Joueur x = attaquant;
		 attaquant = defenseur;
		 defenseur = x;
		 }
		 
	 }
	 
	 protected abstract void retourAttaque(Coordonnee c, int etat);
	 protected abstract void retourDefense(Coordonnee c, int etat);
	 public abstract Coordonnee choixAttaque();
	 public abstract int defendre(Coordonnee c);

	 
	 
	 
	

	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GrilleNavale g1 = new GrilleNavale(6, 4);
		GrilleNavale g2 = new GrilleNavale(6, 4);

        // JoueurTexte joueur1 = new JoueurTexte(g1, "Roihmatoun");
        JoueurTexte joueur2 = new JoueurTexte(g2, "Anais");
        JoueurAuto joueur3= new JoueurAuto(g1, "robot");
        
        Navire n1 = new Navire(new Coordonnee("A2"), 3, true);
		Navire n2 = new Navire(new Coordonnee("C3"), 3, false);
		Navire n3 = new Navire(new Coordonnee("E2"), 2, true);
		Navire n4 = new Navire(new Coordonnee("A4"), 4, false);

		g1.ajouteNavire(n1);
		g1.ajouteNavire(n2);
		g2.ajouteNavire(n3);
		g2.ajouteNavire(n4);
		
		

	//	deroulementJeu(joueur1,joueur2);
		joueur2.jouerAvec(joueur3);

//		joueur1.choixAttaque();
//		g2.recoitTir(joueur1.choixAttaque());
	}

}

