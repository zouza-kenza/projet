package bataillenavale;

import java.util.Arrays;
import java.util.Scanner;


public class JoueurAuto extends JoueurAvecGrille {
	private Scanner sc;
	private GrilleNavale grille;
	private Coordonnee [] tirsRecus;
	private int nbTirs;

	public JoueurAuto(GrilleNavale g, Coordonnee [] tirsRecus, int nbTirs) {
		super(g);
		this.tirsRecus = tirsRecus;
		this.nbTirs = nbTirs;
		
	}
	
	public JoueurAuto(GrilleNavale g, String nom) {
		super(g, nom);
	}
	
	protected void retourAttaque(Coordonnee c, int etat) {
		String res = "";
		if(etat == TOUCHE) {
		   res = res + "Vous avez touch� un navire";
		}
		if(etat == A_L_EAU) {
			res = res + "Vous avez manqu�";
			
		}
		if(etat == COULE) {
		   res = "Vous avez coul� un navire";
		}
		
		if(etat == GAMEOVER) {
			res= "GAME OVER";
		}
		
		System.out.print(c + ":" + res);
		
	}
	
	protected void retourDefense(Coordonnee c, int etat) {
		
		String res = "";
		if(etat == TOUCHE) {
		   res = res + "Touch�";
		}
		if(etat == A_L_EAU) {
			res = res + "Manqu�";
			
		}
		if(etat == COULE) {
		   res = "Coul�";
		}
		
		if(etat == GAMEOVER) {
			res= "Vous avez gagn�!";
		}
		
		System.out.print(c + ":" + res);
		
	}
	
	public Coordonnee choixAttaque() {
	
		// CHANGER LES COORDONNEES POUR LES LIMITES
		
        Coordonnee retour=  new Coordonnee((int) (Math.random() * (this.getTailleGrille())),(int) (Math.random() * (this.getTailleGrille())));
		
		Coordonnee c;
		int randomLig = (int) Math.random() * (this.getTailleGrille()); 
		int randomCol = (int) (Math.random() * (this.getTailleGrille())); 
		c = new Coordonnee(randomLig, randomCol);
     //		return c;
     int etat = 0;
     while (etat != GAMEOVER) {
    		 if(grille.recoitTir(c)) {
    			 Coordonnee [] miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
    			 tirsRecus = miseAJourTirs;
    			 c = tirsRecus[tirsRecus.length];    // mettre � jour tableau a chaque fois?
    			 if(etat != TOUCHE) {
    			
    				 for(int i =0; i < tirsRecus.length; i++) {
    				 if(retour == tirsRecus[i]) {
    					 retour = new Coordonnee((int) (Math.random() * (this.getTailleGrille())),(int) (Math.random() * (this.getTailleGrille())));  // on re-tire au hasard
    					grille.recoitTir(retour);  // on re-tire au hasard
    					miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
   	    			    tirsRecus = miseAJourTirs;
   	    		        retour = tirsRecus[tirsRecus.length];
   	    			    
    				 } else {
    					 grille.recoitTir(retour);  // faire des return au lieu de recoit tir
    					 miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
    	    			 tirsRecus = miseAJourTirs;
    	    			 retour = tirsRecus[tirsRecus.length];
    	    			
    					 
    				 }
    			 }
    	 } else {  
 
    		retour = new Coordonnee(c.getLigne()+1, c.getColonne());
    		
    		 for(int i = 0; i < tirsRecus.length; i++) {
    		 if(c == tirsRecus[i]) {    // si la coordonn�e est dans le tableau alors tirer sur sa voisine, sinon tirer dessus
    			 if(c.getLigne() > 1) {
    				 miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
	    			 tirsRecus = miseAJourTirs;
	    			 retour = tirsRecus[tirsRecus.length];
	    			 return retour;
    			 }
    			 if(c.getLigne() < 25) {
    				 retour = new Coordonnee(c.getLigne()-1, c.getColonne());
    				 miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
	    			 tirsRecus = miseAJourTirs;
	    			 retour = tirsRecus[tirsRecus.length];
	    			 return retour;
    				 
    			 }
    			 
    			 if(c.getColonne()> 0) {
    				 retour = new Coordonnee(c.getLigne(), c.getColonne()+1);
    				 miseAJourTirs = Arrays.copyOf(tirsRecus, nbTirs+1);
	    			 tirsRecus = miseAJourTirs;
	    			 retour = tirsRecus[tirsRecus.length];
    				 return retour;
    			 }
    			 if(c.getColonne()<25) {
    				 retour = new Coordonnee(c.getLigne(), c.getColonne()-1);
    				 tirsRecus = miseAJourTirs;
	    			 retour = tirsRecus[tirsRecus.length];
    				 return retour;
    				
    			 }
    			  //GAME OVER QUAND TIRS RECUS PLEIN
    			 
    		 //grillerecoittirvoisine
    	   // condition pour sortir du while. et aussi si il rate alors qu'il en a touch� un du pr�c�detn, il faut qu'il retente la voisine du pr�c�dent et pas qu'il fas
    			 }
    		 
    		     
    		 }
    		 
    	 }
    		 
    		 
    		 
    	
    		 } 
    		 
     }
     return retour;
     
	}
    	 
         
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
