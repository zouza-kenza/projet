package batailleNavale;

import java.util.Scanner;

public class JoueurTexte extends JoueurAvecGrille{

	private Scanner sc;
	
	public JoueurTexte(GrilleNavale g, String nom) {
		super(g, nom);
		sc = new Scanner(System.in);
		
	}
	
	public JoueurTexte(GrilleNavale g) {
		super(g);
		sc = new Scanner(System.in);
	}
	
	protected void retourAttaque(Coordonnee c, int etat) {
//		System.out.println("================ " + etat);
		String res = "";
		if(etat == TOUCHE) {
		   res = res + "Vous avez touche un navire";
		}
		if(etat == A_L_EAU) {
			res = res + "Vous avez manque";
			
		}
		if(etat == COULE) {
		   res = "Vous avez coule un navire";
		}
		
		if(etat == GAMEOVER) {
			res= "GAME OVER";
		}
		
		System.out.println(res + " en " + c);
		
	}
	
	protected void retourDefense(Coordonnee c, int etat) {
		
		String res = "----------------------------------\n" + getGrille() + getNom() + " ";
		if(etat == TOUCHE) {
		   res = res + "vous avez ete touche en ";
		}
		if(etat == A_L_EAU) {
			res = res + "on a tire dans l'eau à ";
			
		}
		if(etat == COULE) {
		   res = "votre navire a ete coule en ";
		}
		
		if(etat == GAMEOVER) {
			res= "Vous avez perdu !";
		}
		
		System.out.println(res  + c);
		
	}
		
	public Coordonnee choixAttaque() {
	   System.out.print(this.getNom() + ", entrez la coordonnee que vous souhaitez attaquer ");
	   String coordonnee = sc.next();
	   Coordonnee choix = new Coordonnee(coordonnee);
	return choix;
	 
	
		
		

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
