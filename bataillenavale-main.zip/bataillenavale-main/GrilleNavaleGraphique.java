package bataillenavale;

import java.awt.Color;

import bataillenavale.GrilleGraphique;

public class GrilleNavaleGraphique extends GrilleNavale {
	private GrilleGraphique grille;

	public GrilleNavaleGraphique(int taille, int nbNavires) {
		super(taille, nbNavires);
		// TODO Auto-generated constructor stub
	}

	public GrilleNavaleGraphique(int taille) {
		super(taille, taille);
		grille = new GrilleGraphique(taille);
	}

	public GrilleGraphique getGrilleGraphique() {
		return grille;
	}
	
	 public boolean ajouteNavire(Navire n) {
		 if(super.ajouteNavire(n)) {
			 grille.colorie(n.getDebut(), n.getDebut(), Color.GREEN);
			 return true;
		 }
		 return false;
	 }

	 public boolean recoitTir(Coordonnee c) {
		 if(super.recoitTir(c)) {
			grille.colorie(c, Color.RED);
			return true;
		 } else {
			 grille.colorie(c, Color.BLUE);
			 return false;
		 }
	 }

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
