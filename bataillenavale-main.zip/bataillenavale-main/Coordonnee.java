package batailleNavale;

public class Coordonnee implements Comparable<Coordonnee> {
	private int ligne;
	private int colonne;

	public Coordonnee(int ligne, int colonne) {
		if (ligne < 0 || ligne > 25 || colonne < 0 || colonne > 25) {
			throw new IllegalArgumentException("Les coordonnées de ligne et de colonne sont éronnées.");
		}
		this.ligne = ligne;
		this.colonne = colonne;

	}

	public Coordonnee(String s) {
		if (s.length() < 2 || s.length() > 3) {
			throw new IllegalArgumentException(
					"La coordonnee depasse les limites elle doit prendre 2 ou 3 caracteres)");
		}
		this.colonne = s.charAt(0) - 'A';
		this.ligne = Integer.parseInt(s.substring(1)) - 1;

	}

	public String toString() {
		String coordonnees = new String();
		return coordonnees + (char) (this.colonne + 'A') + (this.ligne + 1);
	}

	public int getColonne() {
		return this.colonne;
	}

	public int getLigne() {
		return this.ligne;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Coordonnee) {
			Coordonnee c = (Coordonnee) obj;
			return this.ligne == c.ligne && this.colonne == c.colonne;
		}

		return false;
	}

	public boolean voisine(Coordonnee c) {

		if (this.ligne == c.ligne && (this.colonne == c.colonne - 1 || this.colonne == c.colonne + 1))
			return true;
		if (this.colonne == c.colonne && (this.ligne == c.ligne - 1 || this.ligne == c.ligne + 1))
			return true;
		return false;
	}

	@Override
	public int compareTo(Coordonnee c) {
		if ((this.ligne == c.ligne && this.colonne < c.colonne) || (this.ligne < c.ligne))
			return -1;
		else if (this.ligne == c.ligne && this.colonne == c.colonne)
			return 0;
		else
			return 1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coordonnee coordonnee1 = new Coordonnee("C5");
		Coordonnee coordonnee2 = new Coordonnee(-5, 2);
		Coordonnee coordonnee3 = new Coordonnee("C7");
		System.out.println(coordonnee2);
		System.out.println('Z' - 'A');
		System.out.println((char) (2 + 'A'));
		System.out.println(coordonnee3);
		System.out.println(coordonnee1.equals(coordonnee3));
		System.out.println(coordonnee1.compareTo(coordonnee3));
		System.out.println(new Coordonnee(-4, 3));
	}

}
