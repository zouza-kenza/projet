package bataillenavale;


import java.awt.EventQueue;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;



public class FenetreJoueur extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JFrame frame;

	private  GrilleGraphique grilleTirs;
	private  GrilleNavaleGraphique grilleDefense;

	public FenetreJoueur() {
		this("Nom du joueur", 10);	
	}


	public FenetreJoueur(String nom, int taille) {
		this.grilleTirs = new GrilleGraphique(taille);
		this.grilleDefense = new GrilleNavaleGraphique(taille);
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);	
		getContentPane().setLayout(new GridLayout(1, 2, 0, 0));
		
		JPanel grille1 = new JPanel();
		grille1.setBorder(new TitledBorder(null, "Grille de tir", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		getContentPane().add(grille1);
		
		
		
		
		JPanel grille2 = new JPanel();
		grille2.setBorder(new TitledBorder(null, "Grille de d\u00E9fense", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		getContentPane().add(grille2);
		 
		
		grilleDefense.getGrilleGraphique().setClicActive(false);
	    
		
		grilleTirs = new GrilleGraphique(grilleDefense.getTaille());
	    
	    grille1.add(grilleTirs);
	    grille2.add(grilleDefense.getGrilleGraphique());
	
	}
	
	
		
		
		
		public GrilleGraphique getGrilleTirs() {
			return grilleTirs;
		}

		public GrilleNavaleGraphique getGrilleDefense() {
			return grilleDefense;
		}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue eventQueue;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenetreJoueur frame = new FenetreJoueur();					
					frame.pack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */

}
