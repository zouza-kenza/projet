package batailleNavale;

public class Navire {

  private Coordonnee debut;
    private Coordonnee fin;
	private Coordonnee[] partiesTouchees;
	private int nbTouchees;
	

	
	public Navire(Coordonnee debut, int longueur, boolean estVertical) {
		this.debut = debut; 
		if (estVertical) {//Coordonnee(int ligne, int colonne)
            fin = new Coordonnee(this.debut.getLigne() + longueur - 1, this.debut.getColonne());
        } else {
            fin = new Coordonnee(this.debut.getLigne(), this.debut.getColonne() + longueur - 1);
        }
		partiesTouchees = new Coordonnee[longueur];
		nbTouchees=0; 	
	}
	
	public boolean estVertical() {
		return this.debut.getColonne() == this.fin.getColonne();   
	}

	public int Longueur() {
		 int  longueur = 0; 
		 if(this.estVertical()) {
			 longueur = (this.fin.getLigne() - this.debut.getLigne())+1; 
		 }else{
			 longueur = (this.fin.getColonne() - this.debut.getColonne())+1; 
		 }
		
		return longueur; 
	} 
	
	public String toString() {
		/*Retourne une String représentant this. On souhaite obtenir une représentation de la
		forme "Navire(B1, 4, horizontal)" (pour un navire de taille 4 placé
				horizontalement par exemple).*/
		if (this.partiesTouchees==null)
			throw new RuntimeException("Pas bien!"); 
		
		return "Navire"+"("+this.getDebut()+", "+this.Longueur()+", "+this.estVertical()+")";
	}
	
	public Coordonnee getDebut() {
		return this.debut; 
	}
	
	public Coordonnee getFin() {
		return this.fin; 
	}
	

	public boolean contient(Coordonnee c) {
		if (c==null)
			throw new RuntimeException("La coordonnée est nulle");
		return c.getColonne() >= debut.getColonne()
                && c.getColonne() <= fin.getColonne()
                && c.getLigne() >= debut.getLigne()
                && c.getLigne() <= fin.getLigne();
	}
	
	public boolean touche(Navire n) {
		/*touche ligne et chevauche colonne*/
if((n.fin.getLigne()+1 == this.debut.getLigne()||this.fin.getLigne()+1==n.debut.getLigne())
	&&(this.debut.getColonne()<= n.fin.getColonne() && n.debut.getColonne()<=this.fin.getColonne())) {
	return true;
/*touche colonne et chevauche ligne*/
}else if((n.fin.getColonne()+1 == this.debut.getColonne() || this.fin.getColonne()+1==n.debut.getColonne())
		&& (this.debut.getLigne()<=n.fin.getLigne()
				&& n.debut.getLigne()<=this.fin.getLigne())
		){
	return true; 
}
return false; 
}
	
	public boolean chevauche(Navire n) {
	if (this.debut.getLigne()<=n.fin.getLigne()
			&& n.debut.getLigne()<=this.fin.getLigne()
			&& this.debut.getColonne()<= n.fin.getColonne()
			&& n.debut.getColonne()<=this.fin.getColonne()) {
			return true;
		}return false;
	}
	
	public boolean recoitTir(Coordonnee c) {
		if (c==null)
			throw new RuntimeException("La coordonnée est nulle");
		/*Retourne true si et seulement si this contient c. Dans ce cas, c est ajoutée aux parties
	touchées si nécessaire*/
		if (this.contient(c) && (! this.estTouche(c))) {
			partiesTouchees[nbTouchees] = c;
			nbTouchees++;
			return true;}
			
		return estTouche(c); 	
		
	}
	
	public boolean estTouche(Coordonnee c) {
		if (c==null)
			throw new RuntimeException("La coordonnée est nulle");
		for (int i = 0; i < nbTouchees; i++) {
            		if (partiesTouchees[i].equals(c)) {
                		return true;
            		}
        }

        return false;
    }
    
    public boolean estTouche() {
        return nbTouchees>0;
    }
	
	public boolean estCoule() {
		
		
		if  ( nbTouchees == partiesTouchees.length)
			return true;
	
		return false; 
	}
	public static void main(String[] args) {

	}
	
}
