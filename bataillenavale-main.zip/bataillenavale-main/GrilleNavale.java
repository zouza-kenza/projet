package batailleNavale;

import java.util.Arrays;
import batailleNavale.Coordonnee;
import batailleNavale.Navire;

public class GrilleNavale {
	private Navire[] navires;
	private int nbNavires;
	private int taille;
	private Coordonnee[] tirsRecus;
	private int nbTirsRecus;

	public GrilleNavale(int taille, int[] taillesNavires) {
		this(taille, taillesNavires.length);
		placementAuto(taillesNavires);

	}

	public GrilleNavale(int taille, int nbNavires) {
		this.taille = taille;
		navires = new Navire[nbNavires];
		this.nbNavires = 0;
		tirsRecus = new Coordonnee[taille * taille];
		nbTirsRecus = 0;

	}

	public String toString() {
//		 1-creer A B C D E ......
		StringBuffer s = new StringBuffer();
		s.append("  ");
		for (int i = 0; i < this.taille; i++) {
			s.append(" ").append((char) ('A' + i));
		}
		s.append("\n"); // retourner à la ligne

		int lgLigne = s.length();
		// 2- creer 1 2 3 4 5...
		for (int i = 0; i < this.taille; i++) {
			if (i < 9) {
				s.append(" ");
			}

			s.append(i + 1);
			for (int j = 0; j < this.taille; j++) {
				s.append(" ").append(".");
			}
			s.append("\n");
		}
//					
		// NAVIRES
		int indDebut, indFin;
		for (int i = 0; i < nbNavires; i++) {
			int linDeb = navires[i].getDebut().getLigne();
			int colDeb = navires[i].getDebut().getColonne();

			int linFin = navires[i].getFin().getLigne();
			int colFin = navires[i].getFin().getColonne();

//					System.out.println("debut " + navires[i].getDebut() + ", lig = " + linDeb + ", col = " + colDeb);
//					System.out.println("fin   " + navires[i].getFin() + ", lig = " + linFin + ", col = " + colFin);

			// NAVIRE Horizontal
			if (linDeb == linFin) {

				indDebut = (linDeb + 1) * lgLigne + 3 + colDeb * 2;
				indFin = (linFin + 1) * lgLigne + 3 + colFin * 2;
				for (int j = indDebut; j <= indFin; j += 2) {
					s.setCharAt(j, '#');
				}
//						s.setCharAt(indDebut, '#');
			}
			// VERTICAL
			else {

				indDebut = (linDeb + 1) * lgLigne + 3 + colDeb * 2;
				indFin = (linFin + 1) * lgLigne + 3 + colFin * 2;
				for (int j = indDebut; j <= indFin; j += lgLigne) {
					s.setCharAt(j, '#');
				}
			}

		}
		// TOUCHER OU A L'EAU
		for (int i = 0; i < nbTirsRecus; i++) {

			int j = (tirsRecus[i].getLigne() + 1) * lgLigne + 3 + tirsRecus[i].getColonne() * 2;
			if (s.charAt(j) == '#')
				s.setCharAt(j, 'X');
			else
				s.setCharAt(j, 'O');

		}

		return s.toString();

	}

	public int getTaille() {
		return taille;
	}

	public boolean ajouteNavire(Navire n) {
		// if ((n.getFin().getLigne() >= taille) || (n.getFin().getColonne() >= taille))
		// {
		// return false;
		// }

		for (int i = 0; i < nbNavires; i++) {
			if (navires[i].chevauche(n) || (navires[i].touche(n))) {
				return false;
			}
		}

		navires[nbNavires] = n;
		nbNavires++;
		return true;

	}

	public int getNavire() {
		return navires.length;
	}

	public void placementAuto(int[] taillesNavires) {
		if (taillesNavires.length > navires.length)
			throw new IllegalArgumentException("Il y a trop de navires par rapport à la capacité de la grille");
		int colonne = 0;
		int ligne = 0;
		Coordonnee c = null;
		boolean estVertical = false;
		Navire navireRandom = null;

		for (int i = 0; i < taillesNavires.length; i++) {
			System.out.println("Navire " + i);
			do {
				estVertical = Math.random() < 0.5;
//					int VerticalouHorizontal = (int) Math.random() * 2;
//					if (VerticalouHorizontal == 1) {
//						estVertical = true;
//					} else {
//						estVertical = false;
//					}
				if (estVertical) {
					ligne = (int) (Math.random() * (taille - taillesNavires[i]));
					colonne = (int) (Math.random() * taille); // le navire est dans le sens de la colonne
				} else {
					ligne = (int) (Math.random() * taille); // le navire est dans le sens de la ligne
					colonne = (int) (Math.random() * (taille - taillesNavires[i]));
				}
				c = new Coordonnee(ligne, colonne);
				navireRandom = new Navire(c, taillesNavires[i], estVertical);
//				System.out.println(navireRandom);
			} while (!ajouteNavire(navireRandom));
		}

	}

	private boolean estDansGrille(Coordonnee c) {
		return c.getLigne() < this.taille && c.getColonne() < this.taille;
	}

	private boolean estDansTirsRecus(Coordonnee c) {
		for (int i = 0; i < nbTirsRecus; i++) {
			if (tirsRecus[i] == c) {
				return true;
			}
		}

		return false;
	}

	private boolean ajouteDansTirsRecus(Coordonnee c) {

		if (this.estDansTirsRecus(c) == true)
			return false;
		tirsRecus[nbTirsRecus] = c;
		nbTirsRecus++;
		return true;
	}

	public boolean recoitTir(Coordonnee c) {
		if (!ajouteDansTirsRecus(c))
			return false;
		for (int i = 0; i < nbNavires; i++) {
			if (navires[i].recoitTir(c))
				return true;
		}
		return false;
	}

	public boolean estTouche(Coordonnee c) {
		for (int i = 0; i < nbNavires; i++) {
			if (navires[i].estTouche(c)) {
				return true;
			}
		}
		return false;
	}

	public boolean estALEau(Coordonnee c) {
		return !estTouche(c);
	}

	public boolean estCoule(Coordonnee c) {
		for (int i = 0; i < nbNavires; i++) {
			if (navires[i].estCoule()) {
				return true;
			}
		}
		return false;
	}

	public boolean perdu() {
		for (int i = 0; i < nbNavires; i++) {
			if (!navires[i].estCoule()) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
//		GrilleNavale grille = new GrilleNavale(12, 6);
//
//		// creer Navire
//		Navire n1 = new Navire(new Coordonnee("A2"), 3, true);
//		Navire n2 = new Navire(new Coordonnee("C3"), 3, false);
//		Navire n3 = new Navire(new Coordonnee("J5"), 3, true);
//		Navire n4 = new Navire(new Coordonnee("C4"), 4, true);
//
//		grille.ajouteNavire(n1);
//		grille.ajouteNavire(n2);
//		grille.ajouteNavire(n3);
//		grille.ajouteNavire(n4);
//
//		for (int i = 0; i < grille.nbNavires; i++)
//			System.out.println("Navire : " + grille.navires[i]);
//
//		// creer des coordonnee
//			 Coordonnee c1 = new Coordonnee("A3");
//			 Coordonnee c2 = new Coordonnee("E9");
//			 Coordonnee c3 = new Coordonnee(5, 5);
//			 Coordonnee c4 = new Coordonnee(7, 2);
//				
//			 
//			 grille.recoitTir(new Coordonnee("A2")); 
//			 grille.recoitTir(new Coordonnee("F2"));
//			 grille.recoitTir(c1);
//			 grille.recoitTir(c3);
//
//		String grilleenchaine = grille.toString();
//		System.out.println(grilleenchaine);

		GrilleNavale g = new GrilleNavale(7, new int[] { 2, 3, 4, 2, 5, 3 });
		String s = g.toString();
		System.out.println(g);
		System.out.println(s);

	}

}
