package bataillenavale;

public abstract class JoueurAvecGrille extends Joueur {
	private GrilleNavale grille;
	
	public JoueurAvecGrille(GrilleNavale g,String nom) {
		super(g.getTaille(),nom);
		this.grille = g;
		
	}

	public JoueurAvecGrille(GrilleNavale g) {
		super(g.getTaille());
		this.grille = grille;
		
	}
	


	public int defendre(Coordonnee c) {	
        int etat = 0;
        grille.recoitTir(c);
//        if ( grille.recoitTir(c)) {
        	 if (grille.estTouche(c))
        		 etat = TOUCHE;
        	 if (grille.estCoule(c))
        		 etat = COULE;
        	 if (grille.estALEau(c))
        		 etat = A_L_EAU;
        	 if (grille.perdu())
        		 etat = GAMEOVER;
//        }
        return etat;
	}
        
	public GrilleNavale getGrille() {
		return grille;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GrilleNavale g = new GrilleNavale(24, 12);
		GrilleNavale g1 = new GrilleNavale(24, 12);

        JoueurTexte joueur1 = new JoueurTexte(g, "Roihmatoun");
        JoueurTexte joueur2 = new JoueurTexte(g1, "Anais");
        
		// creer Navire
		Navire n1 = new Navire(new Coordonnee("A2"), 3, true);
		Navire n2 = new Navire(new Coordonnee("C3"), 3, false);
		Navire n3 = new Navire(new Coordonnee("J5"), 3, true);
		Navire n4 = new Navire(new Coordonnee("C4"), 4, true);

		g.ajouteNavire(n1);
		g.ajouteNavire(n2);
		g.ajouteNavire(n3);
		g.ajouteNavire(n4);
		Coordonnee c = new Coordonnee("S5");
        
	    joueur2.choixAttaque();
		// creer des coordonnee
			 Coordonnee c1 = new Coordonnee("A3");
			 Coordonnee c2 = new Coordonnee("E9");
			 Coordonnee c3 = new Coordonnee(5, 5);
			 Coordonnee c4 = new Coordonnee(7, 2);
				
			 
			 g.recoitTir(new Coordonnee("A2")); 
			 g.recoitTir(new Coordonnee("F2"));
			 g.recoitTir(c1);
			 g.recoitTir(c3);

		String grilleenchaine = g.toString();
		String grilleenchaine1 = g1.toString();

		
		
		System.out.println("\n");

		System.out.println(grilleenchaine);
		System.out.println(grilleenchaine1);

		
	}

}
